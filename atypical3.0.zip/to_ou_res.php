<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <link rel="shortcut icon" type="imagex/png" href = "./assets/img/iconpq.png ">
  <link rel="stylesheet" href="./assets/styles/style_to_ou_resp.css">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tela Cadastro</title>
</head>
<body>
<body>
  
    <div>
      <h1>Cadastro</h1>
      <H2>Você é?</H2>
      <br><br>
  <form action="cadastro_terapeuta.php">
      <button type="submit">Terapeuta</button>
      <br><br>
      </form>
      <form action="cadastrocrianca.php">
      <button type="submit">Responsável</button>
  </form>

    </div>

</body>
</html>